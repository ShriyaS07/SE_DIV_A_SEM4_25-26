import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://tepexpcwphyoniwroubx.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRlcGV4cGN3cGh5b25pd3JvdWJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3NzQ3MzgsImV4cCI6MjA4NjM1MDczOH0.ZsONYe_50R79RkbQD-xbeVygR-Unnbz0h-hZKpylYJE'

// MAKE SURE THIS LINE HAS "export" AT THE START
export const supabase = createClient(supabaseUrl, supabaseKey)