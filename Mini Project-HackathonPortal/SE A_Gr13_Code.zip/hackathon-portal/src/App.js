import React, { useState, useEffect } from 'react';
import { supabase } from './supabaseClient';
import emailjs from '@emailjs/browser';
import './App.css';

function App() {
  const [view, setView] = useState('landing'); 
  const [user, setUser] = useState(null);
  const [hackathons, setHackathons] = useState([]);
  const [userRegs, setUserRegs] = useState([]);

  const SECRET_CODE = "123";

  useEffect(() => {
    fetchHackathons();
  }, []);

  useEffect(() => {
    if (user) {
      fetchUserRegistrations();
    }
  }, [user]);

  async function fetchHackathons() {
  const { data, error } = await supabase.from('hackathons').select('*');
  
  if (error) {
    console.error("Supabase Error:", error.message);
  } else {
    console.log("Data received:", data);
    setHackathons(data || []);
  }
  }

  async function fetchUserRegistrations() {
    if (!user) return;
    const { data, error } = await supabase.from('registrations').select('*').contains('moodle_ids', [user.moodle_id]);
    if (error) {
      console.error("Supabase Error:", error.message);
    } else {
      setUserRegs(data || []);
  }
}

  // --- NAVIGATION ---
  if (view === 'landing') return (
    <div className="container" style={{textAlign: 'center', marginTop: '150px'}}>
      <h1 style={{fontSize: '4rem', color: '#059669', fontWeight: '800'}}>HackPortal</h1>
      <p style={{color: '#374151', fontSize: '1.2rem', marginBottom: '40px'}}>The central hub for student innovation.</p>
      <div style={{display: 'flex', gap: '20px', justifyContent: 'center'}}>
        <button className="btn-primary" style={{width: '220px'}} onClick={() => setView('student_auth')}>Student Portal</button>
        <button className="btn-view" style={{width: '220px'}} onClick={() => setView('admin_auth')}>Admin Portal</button>
      </div>
    </div>
  );

  if (view === 'admin_auth') return (
    <div className="container"><div className="card" style={{maxWidth: '400px', margin: 'auto'}}>
      <h2 style={{marginTop: 0}}>Admin Login</h2>
      <input type="password" placeholder="Enter Secret Code" id="acode" />
      <button className="btn-primary" style={{width: '100%'}} onClick={() => document.getElementById('acode').value === SECRET_CODE ? setView('admin_dash') : alert("Wrong Code")}>Enter Dashboard</button>
      <button className="btn-view" style={{width: '100%', marginTop: '10px'}} onClick={() => setView('landing')}>Back</button>
    </div></div>
  );

  if (view === 'admin_dash') return <AdminDashboard back={() => setView('landing')} fetch={fetchHackathons} hackathons={hackathons} />;
  
  if (view === 'student_auth') return <StudentLogin onLogin={(u) => { setUser(u); setView('student_dash'); }} back={() => setView('landing')} />;
  
  if (view === 'student_dash') {
    if (!user) return <div className="container">Loading Profile...</div>;
    return <StudentDashboard user={user} setUser={setUser} hackathons={hackathons} userRegs={userRegs} refreshRegs={fetchUserRegistrations} logout={() => {setUser(null); setView('landing');}} />;
  }
}

// --- SHARED COMPONENTS ---
function FilterBar({ setSearch, setBranch }) {
  return (
    <div className="controls-row">
      <input 
        className="search-input" 
        placeholder="🔍 Search by hackathon title..." 
        onChange={(e) => setSearch(e.target.value)} 
      />
      <select className="filter-select" onChange={(e) => setBranch(e.target.value)}>
        <option value="ALL">All Branches</option>
        <option>COMPUTER</option><option>AIML</option><option>DATA SCIENCE</option><option>IT</option>
        <option>MECHANICAL</option><option>CIVIL</option><option>CYBERSECURITY</option><option>DEVOPS</option>
      </select>
    </div>
  );
}

// --- ADMIN SECTION ---
function AdminDashboard({ back, fetch, hackathons }) {
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: '', description: '', branch: 'COMPUTER', min_team: 1, max_team: 1, start_date: '', end_date: '', news_note: '', release_at: '',rounds_info: '' });
  const [search, setSearch] = useState("");
  const [branch, setBranch] = useState("ALL");

  const broadcastEmail = async (title) => {
    // 1. Fetch all student emails
    const { data: students } = await supabase.from('students').select('email');
    if (!students || students.length === 0) return;

    // 2. EmailJS Configuration
    const SERVICE_ID = 'service_1dqhdvp';
    const TEMPLATE_ID = 'template_9vqxorf';
    const PUBLIC_KEY = '-ruLSY7n71dBCKo75';

    // 3. Send to each student
    students.forEach(student => {
      if (student.email) {
        emailjs.send(SERVICE_ID, TEMPLATE_ID, { hackathon_title: title, to_email: student.email }, PUBLIC_KEY)
          .catch(err => console.error("Broadcast failed for: " + student.email, err));
      }
    });
    alert('Announcement Live! Notifying ${students.length} students via email.');
  };

  async function createNew() {
    if(!form.title) return alert("Title required");
    
    // FIX: Convert empty strings to null for DB safety
    const payload = { 
        ...form,
        start_date: form.start_date || null,
        end_date: form.end_date || null,
        release_at: form.release_at || null
    };

    const { error } = await supabase.from('hackathons').insert([payload]);
    
    if (error) {
        alert("Database Error: " + error.message);
    } else {
        broadcastEmail(form.title);
        fetch();
    }
  }

  async function saveEdit() {
    await supabase.from('hackathons').update(editing).eq('id', editing.id);
    alert("Updated Successfully!");
    setEditing(null);
    fetch();
  }

  async function deleteHackathon(id) {
    if (window.confirm("Are you sure?")) {
      await supabase.from('hackathons').delete().eq('id', id);
      fetch();
    }
  }

  const downloadCSV = async (h) => {
    const { data } = await supabase.from('registrations').select('*').eq('hackathon_id', h.id);
    if(!data || data.length === 0) return alert("No participants yet.");
    let csvContent = "Team Name,Member Names,Moodle IDs\n";
    data.forEach(row => {
      csvContent += `"${row.team_name}","${row.member_names.join(', ')}","${row.moodle_ids.join(', ')}"\n`;
    });
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${h.title}_Participants.csv`;
    a.click();
  };

  const filteredHackathons = hackathons.filter(h => {
    const matchesSearch = (h.title || "").toLowerCase().includes(search.toLowerCase());
    const matchesBranch = branch === "ALL" || h.branch === branch;
    return matchesSearch && matchesBranch;
  });

  return (
    <div>
      <div className="navbar"><h2>Admin Panel</h2><button onClick={back} className="btn-view" style={{width: '100px'}}>Logout</button></div>
      <div className="container">
        <div className="card" style={{borderTop: '5px solid #10b981'}}>
          <h3>🚀 Create New Announcement</h3>
          <input placeholder="Hackathon Title" onChange={e => setForm({...form, title: e.target.value})} />
          <select onChange={e => setForm({...form, branch: e.target.value})}>
            <option>COMPUTER</option><option>AIML</option><option>DATA SCIENCE</option><option>IT</option>
            <option>MECHANICAL</option><option>CIVIL</option><option>CYBERSECURITY</option><option>DEVOPS</option>
          </select>
          <textarea placeholder="Description" onChange={e => setForm({...form, description: e.target.value})} />
          <textarea placeholder="Rounds Details (e.g., Round 1: Selection list...)" onChange={e => setForm({...form, rounds_info: e.target.value})} />
          <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '10px'}}>
             <div><label style={{fontSize: '12px'}}>Registration Start</label><input type="date" onChange={e => setForm({...form, start_date: e.target.value})} /></div>
             <div><label style={{fontSize: '12px'}}>Registration End</label><input type="date" onChange={e => setForm({...form, end_date: e.target.value})} /></div>
          </div>

          <div style={{background: '#f0f9ff', padding: '15px', borderRadius: '12px', border: '1px solid #bae6fd', marginBottom: '15px'}}>
            <label style={{fontWeight: 'bold', display: 'block', marginBottom: '5px'}}>⏲️ Schedule Release (Problem Statement Reveal)</label>
            <input type="datetime-local" onChange={e => setForm({...form, release_at: e.target.value})} />
            <small style={{color: '#0369a1'}}>Students won't see this until the time above. Leave empty for immediate post.</small>
          </div>

          <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px'}}>
             <input type="number" placeholder="Min Team" onChange={e => setForm({...form, min_team: Math.max(1, e.target.value)})} />
             <input type="number" placeholder="Max Team" onChange={e => setForm({...form, max_team: Math.max(1, e.target.value)})} />
          </div>
          <button className="btn-primary" style={{width: '100%', marginTop: '10px'}} onClick={createNew}>Publish & Notify All Students</button>
        </div>

        <FilterBar setSearch={setSearch} setBranch={setBranch} />

        <div className="grid">
          {filteredHackathons.map(h => {
            const isScheduled = h.release_at && new Date(h.release_at) > new Date();
            return (
              <div className="card" key={h.id} style={{opacity: isScheduled ? 0.7 : 1}}>
                <span className="badge">{h.branch}</span>
                {isScheduled && <span className="badge" style={{marginLeft: '5px', background: '#fef3c7', color: '#92400e'}}>⏳ SCHEDULED</span>}
                <h4>{h.title}</h4>
                {isScheduled && <p style={{fontSize: '11px', color: '#b45309'}}>Releases: {new Date(h.release_at).toLocaleString()}</p>}
                <button className="btn-primary" style={{width: '100%', marginBottom: '10px'}} onClick={() => setEditing(h)}>Edit / Post News</button>
                <button className="btn-view" style={{width: '100%', marginBottom: '10px'}} onClick={() => downloadCSV(h)}>📥 Download CSV</button>
                <button className="btn-view" style={{width: '100%', background: '#fee2e2', color: '#ef4444', border: '1px solid #fecdd3'}} onClick={() => deleteHackathon(h.id)}>🗑 Delete Announcement</button>
              </div>
            );
          })}
        </div>
      </div>
      {editing && (
        <div className="modal-overlay"><div className="modal-content">
          <h3>Edit: {editing.title}</h3>
          <textarea value={editing.news_note || ""} placeholder="Post News/Note..." onChange={e => setEditing({...editing, news_note: e.target.value})} />
          <textarea value={editing.description || ""} onChange={e => setEditing({...editing, description: e.target.value})} />
          <textarea placeholder="Rounds Details (e.g., Round 1: Selection list...)" value={editing.rounds_info || ""} onChange={e => setEditing({...editing, rounds_info: e.target.value})} />
          <button className="btn-primary" style={{width: '100%'}} onClick={saveEdit}>Save Changes</button>
          <button className="btn-view" style={{width: '100%', marginTop: '10px'}} onClick={() => setEditing(null)}>Cancel</button>
        </div></div>
      )}
    </div>
  );
}

// --- STUDENT LOGIN ---
function StudentLogin({ onLogin, back }) {
  const [isNew, setIsNew] = useState(false);
  const [f, setF] = useState({ full_name: '', moodle_id: '', email: '', password: '', branch: 'COMPUTER' });

  const handle = async () => {
    if (isNew) {
      if(!f.full_name || !f.moodle_id || !f.email || !f.password) return alert("Fill all fields");
      const { data, error } = await supabase.from('students').insert([f]).select().single();
      if (error) alert("Moodle ID or Email already registered"); else onLogin(data);
    } else {
      const { data } = await supabase.from('students').select('*').eq('moodle_id', f.moodle_id).eq('password', f.password).single();
      if (data) onLogin(data); else alert("Invalid Credentials");
    }
  };

  return (
    <div className="container"><div className="card" style={{maxWidth: '400px', margin: 'auto'}}>
      <h2>{isNew ? 'Join Portal' : 'Student Login'}</h2>
      {isNew && <input placeholder="Full Name" onChange={e => setF({...f, full_name: e.target.value})} />}
      <input placeholder="Moodle ID" onChange={e => setF({...f, moodle_id: e.target.value})} />
      {isNew && <input type="email" placeholder="Email Address" onChange={e => setF({...f, email: e.target.value})} />}
      <input type="password" placeholder="Password" onChange={e => setF({...f, password: e.target.value})} />
      <button className="btn-primary" onClick={handle}>{isNew ? 'Sign Up' : 'Login'}</button>
      <p style={{textAlign: 'center', cursor: 'pointer', color: '#059669', marginTop: '25px'}} onClick={() => setIsNew(!isNew)}>
        {isNew ? "Login instead" : "Create Account"}
      </p>
      <button className="btn-view" style={{width: '100%', marginTop: '10px'}} onClick={back}>Back Home</button>
    </div></div>
  );
}

function StudentDashboard({ user, setUser, hackathons, userRegs, refreshRegs, logout }) {
  const [selH, setSelH] = useState(null);
  const [viewDetails, setViewDetails] = useState(null);
  const [showProfile, setShowProfile] = useState(false);
  const [profUpdate, setProfUpdate] = useState({ password: '', email: user.email || '' });
  const [teamSize, setTeamSize] = useState(1);
  const [teamData, setTeamData] = useState({ teamName: '', members: [] });
  const [search, setSearch] = useState("");
  const [branch, setBranch] = useState("ALL");

  const getStatus = (hId) => userRegs.find(r => r.hackathon_id === hId);

  const startRegistration = (h) => {
    setSelH(h);
    setTeamSize(h.min_team);
    setTeamData({ teamName: '', members: Array(Number(h.min_team)).fill({ name: '', id: '' }) });
  };

  const updateTeamSize = (val) => {
    const size = parseInt(val);
    setTeamSize(size);
    setTeamData({...teamData, members: Array(size).fill({ name: '', id: '' })});
  };

  const submitReg = async () => {
    if(!teamData.teamName) return alert("Team Name required");
    const { data: alreadyReg } = await supabase.from('registrations')
      .select('id').eq('hackathon_id', selH.id).contains('moodle_ids', [user.moodle_id]);
    
    if(alreadyReg && alreadyReg.length > 0) return alert("Already registered!");

    const ids = teamData.members.map(m => m.id);
    const names = teamData.members.map(m => m.name);

    if(names.some(n => !n) || ids.some(i => !i)) return alert("Please fill all details");

    const { error } = await supabase.from('registrations').insert([{
      hackathon_id: selH.id,
      team_name: teamData.teamName,
      moodle_ids: ids,
      member_names: names
    }]);

    if (error) alert("Error saving registration.");
    else { alert("Success!"); setSelH(null); refreshRegs(); }
  };

  const updateProfile = async () => {
    const updates = {};
    if (profUpdate.password) updates.password = profUpdate.password;
    if (profUpdate.email) updates.email = profUpdate.email;

    const { data, error } = await supabase.from('students').update(updates).eq('id', user.id).select().single();
    if (error) alert("Update failed");
    else { alert("Profile Updated!"); setUser(data); setShowProfile(false); }
  };

  const filteredHackathons = hackathons.filter(h => {
    const matchesSearch = (h.title || "").toLowerCase().includes(search.toLowerCase());
    const matchesBranch = branch === "ALL" || h.branch === branch;
    const isReleased = h.release_at ? new Date(h.release_at) <= new Date() : true;
    return matchesSearch && matchesBranch && isReleased;
  });

  return (
    <div>
      <div className="navbar">                                    
        <h2 style={{color: '#059669'}}>HackPortal</h2>
        <div style={{display: 'flex', gap: '15px'}}>
          <button className="btn-view" onClick={() => setShowProfile(true)}>Profile</button>
          <button className="btn-view" style={{background: '#fee2e2', color: '#ef4444'}} onClick={logout}>Logout</button>
        </div>
      </div>

      <div className="container">
        <h3>Welcome, <span style={{color: '#059669'}}>{user.full_name}</span></h3>
        <FilterBar setSearch={setSearch} setBranch={setBranch} />

        <div className="grid">
          {filteredHackathons.map(h => {
            const reg = getStatus(h.id);
            const hasNews = h.news_note && h.news_note.length > 0;
            let cName = "card";
            if (reg) cName += " card-registered";
            if (reg && hasNews) cName += " card-news";

            return (
              <div className={cName} key={h.id}>
                <span className="badge">{h.branch}</span>
                <h4 style={{margin: '15px 0'}}>{h.title}</h4>
                
                <button className="btn-view" style={{width: '100%', marginBottom: '10px'}} onClick={() => setViewDetails({h, reg})}>
                    {reg ? "View Team & News" : "View Description"}
                </button>

                {!reg && (
                  <button className="btn-primary" style={{width: '100%'}} onClick={() => startRegistration(h)}>
                    Register Now
                  </button>
                )}
                
                {reg && <p style={{textAlign: 'center', fontSize: '12px', fontWeight: 'bold', color: '#059669', marginTop: '5px'}}>✓ Registered</p>}
              </div>
            );
          })}
        </div>
      </div>

      {/* REGISTRATION POPUP */}
      {selH && (
        <div className="modal-overlay"><div className="modal-content">
          <h3>Register for {selH.title}</h3>
          <input placeholder="Team Name" onChange={e => setTeamData({...teamData, teamName: e.target.value})} />
          <select value={teamSize} onChange={e => updateTeamSize(e.target.value)}>
            {Array.from({length: (Number(selH.max_team) - Number(selH.min_team)) + 1}, (_, i) => i + parseInt(selH.min_team)).map(n => (
              <option key={n} value={n}>{n} Members</option>
            ))}
          </select>
          {teamData.members.map((_, i) => (
            <div key={i} style={{padding: '15px', background: '#f0fdf4', marginTop: '10px', borderRadius: '15px', border: '1px solid #d1fae5'}}>
              <input placeholder="Name" onChange={e => {
                let m = [...teamData.members]; m[i] = {...m[i], name: e.target.value}; setTeamData({...teamData, members: m});
              }} />
              <input placeholder="Moodle ID" onChange={e => {
                let m = [...teamData.members]; m[i] = {...m[i], id: e.target.value}; setTeamData({...teamData, members: m});
              }} />
            </div>
          ))}
          <button className="btn-primary" style={{width: '100%', marginTop: '20px'}} onClick={submitReg}>Submit</button>
          <button className="btn-view" style={{width: '100%', marginTop: '10px'}} onClick={() => setSelH(null)}>Cancel</button>
        </div></div>
      )}

      {/* DETAILS POPUP */}
      {viewDetails && (
        <div className="modal-overlay"><div className="modal-content">
          <h2 style={{color: '#059669', marginTop: 0}}>{viewDetails.h.title}</h2>
          
          {viewDetails.h.news_note && (
            <div style={{background: '#fef9c3', padding: '15px', borderRadius: '15px', border: '1px solid #fef08a', marginBottom: '20px'}}>
              <strong>🔔 News Alert:</strong> <p>{viewDetails.h.news_note}</p>
            </div>
          )}

          <p><strong>Branch:</strong> {viewDetails.h.branch}</p>
          <p><strong>Description:</strong></p>
          <div style={{background: '#f8fafc', padding: '15px', borderRadius: '15px', border: '1px solid #e2e8f0', marginBottom: '20px'}}>
            {viewDetails.h.description || 'No description provided.'}
          </div>
          {/* --- ROUNDS DISPLAY SECTION --- */}
          {viewDetails.h.rounds_info && (
          <div style={{background: '#f1f5f9', padding: '15px', borderRadius: '15px', border: '1px solid #cbd5e1', marginBottom: '20px'}}>
          <strong style={{color: '#475569'}}>🏁 Rounds:</strong>
          <p style={{whiteSpace: 'pre-wrap', marginTop: '10px', fontSize: '14px', color: '#334155'}}>
          {viewDetails.h.rounds_info}
          </p>
          </div>
          )}
          
          {viewDetails.reg && (
            <div style={{background: '#f0fdf4', padding: '15px', border: '1px solid #d1fae5', borderRadius: '15px'}}>
              <strong style={{color: '#059669'}}>Your Registered Team: {viewDetails.reg.team_name}</strong>
              <ul style={{marginTop: '10px', paddingLeft: '20px'}}>
                {viewDetails.reg.member_names.map((n, i) => <li key={i}>{n} ({viewDetails.reg.moodle_ids[i]})</li>)}
              </ul>
            </div>
          )}

          <button className="btn-view" style={{width: '100%', marginTop: '20px'}} onClick={() => setViewDetails(null)}>Close</button>
        </div></div>
      )}

      {/* PROFILE POPUP */}
      {showProfile && (
        <div className="modal-overlay"><div className="modal-content">
          <h3>Student Profile</h3>
          <p><strong>Name:</strong> {user.full_name}</p>
          <p><strong>Moodle ID:</strong> {user.moodle_id}</p>
          
          <label style={{fontSize: '12px', fontWeight: 'bold'}}>Email Address</label>
          <input type="email" value={profUpdate.email} onChange={e => setProfUpdate({...profUpdate, email: e.target.value})} />
          
          <label style={{fontSize: '12px', fontWeight: 'bold'}}>New Password (Leave blank to keep current)</label>
          <input type="password" placeholder="••••••••" onChange={e => setProfUpdate({...profUpdate, password: e.target.value})} />
          
          <button className="btn-primary" style={{width: '100%', marginTop: '10px'}} onClick={updateProfile}>Update Profile</button>
          <button className="btn-view" style={{width: '100%', marginTop: '10px'}} onClick={() => setShowProfile(false)}>Close</button>
        </div></div>
      )}
    </div>
  );
}
export default App;